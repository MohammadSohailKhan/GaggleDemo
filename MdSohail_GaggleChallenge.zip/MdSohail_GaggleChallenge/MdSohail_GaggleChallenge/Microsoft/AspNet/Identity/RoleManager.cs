﻿using System;

namespace Microsoft.AspNet.Identity
{
    internal class RoleManager
    {
        internal static bool RoleExists(string v)
        {
            throw new NotImplementedException();
        }
    }
}