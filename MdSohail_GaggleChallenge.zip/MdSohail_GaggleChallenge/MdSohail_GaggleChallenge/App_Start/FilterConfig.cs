﻿using System.Web;
using System.Web.Mvc;

namespace MdSohail_GaggleChallenge
{
    public class FilterConfig
    {
        public static void RegisterGlobalFilters(GlobalFilterCollection filters)
        {
            filters.Add(new HandleErrorAttribute());
        }
    }
}
