﻿namespace MdSohail_GaggleChallenge.Migrations.Identity
{
    internal class rolestore<T1>
    {
    }
}