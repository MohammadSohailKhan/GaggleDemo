﻿using System;
using Microsoft.AspNet.Identity.EntityFramework;

namespace MdSohail_GaggleChallenge.Migrations.Identity
{
    internal class roleManger
    {
        internal static void Create(IdentityRole identityRole)
        {
            throw new NotImplementedException();
        }

        internal static bool RoleExists(string v)
        {
            throw new NotImplementedException();
        }
    }
}