﻿namespace MdSohail_GaggleChallenge.Migrations.Identity
{
    internal class identityrole
    {
    }
}