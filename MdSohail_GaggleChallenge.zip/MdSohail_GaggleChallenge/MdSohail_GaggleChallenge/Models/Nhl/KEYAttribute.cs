﻿using System;

namespace MdSohail_GaggleChallenge.Models.Nhl
{
    internal class KEYAttribute : Attribute
    {
    }
}